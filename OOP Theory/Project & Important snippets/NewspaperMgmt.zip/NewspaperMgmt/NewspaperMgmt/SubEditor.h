#pragma once
#include <iostream>
#include <string>
using namespace std;

class SubEditor
{
		string name;
public:
	SubEditor(string);

	void setName(string);
	string getName();
	string EditNews(string);


};

