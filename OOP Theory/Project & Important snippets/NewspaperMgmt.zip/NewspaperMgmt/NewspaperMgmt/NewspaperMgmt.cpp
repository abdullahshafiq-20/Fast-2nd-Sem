#include <iostream>
#include "stdafx.h"
#include "Reporter.h"
using namespace std;

int main()
{
	Reporter r1("Alam");
	r1.SubmitReport();
}

